const button = document.querySelector('button');
const output = document.querySelector('p');

function trackUserHandler() {
  navigator.geolocation.getCurrentPosition(
    posData => {
      console.log("In getcurrentposition but outside timeout");
      setTimeout(() => {
        console.log(posData);
      }, 2000);
    },
    error => {
      console.log(error);
    }
  );
  setTimeout(() => {
    console.log('Timer done!');
  }, 0);
  console.log('Getting position...');
  console.log("Another message");
  let i = 0;
  for (i = 0; i < 1000000; i++) {
    a = i;
  }
  console.log("After loop");
}

button.addEventListener('click', trackUserHandler);


