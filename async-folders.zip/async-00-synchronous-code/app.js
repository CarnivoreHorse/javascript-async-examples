console.log("I'm here!");

let a = 4;

function blah() {
  console.log("Now I'm there!")
}

setTimeout(blah, 0);

console.log(a);

a = 5;

console.log(a);
