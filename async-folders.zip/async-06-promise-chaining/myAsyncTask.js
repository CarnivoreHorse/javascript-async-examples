myAsyncTask()
    .then(() => {
        return something;
    })
    .then(() => {
        return somethingElse;
    })
    .then(() => {
        return anotherSomething;
    });

